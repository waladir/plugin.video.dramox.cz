<h1>Dramox</h1>
<p>
<h3>Kodi doplňek pro Dramox, který nabízí streamy divadelních her z několika desítek scén</h3>
<p>
Pro fungování doplňku je potřeba mít registrace a aktivní předplatné na dramox.cz<br><br>
<a href="https://www.xbmc-kodi.cz/prispevek-dramox">Vlákno na fóru XBMC-Kodi.cz</a><br><br>

v1.0.0 (5.12.2022)<br>
- první verze<br><br>
</p>
